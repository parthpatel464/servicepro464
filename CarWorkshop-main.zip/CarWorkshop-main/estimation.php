<!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" href="css/main.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
   </head>
   <body class="hero-image">
      </div>
                <!-- Nav bar -->
   <?php require 'nav.html' ?>

    
      <!-- Nav bar finishh -->
      <!-- login section -->
      <section class="center newp">
         <div style="padding-left:100px">
            <div style="padding-right:100px">
               <h2 style="color:white" >
                  <!-- put text here -->
                  Estimation Form
               </h2>
               <form action="/action_page.php" method="post">
                  <div class="container" style="background-color:#181818 ">
                     <div class="testbox" style="color:white">
               <form action="/">
               <h1>Customer Vehicle Information</h1>
               <input class="inspectioninput" type="text" id="jobid"  name="jobid" placeholder="JobID">
              
               <br>
               <h3>Overall Vehicle Inspection</h3>
               <div style="text-align:justify-all;">
               Periodic Service 
               <input type="checkbox" name="remember" STYLE="color:white">
               Oil Change
               <input type="checkbox" name="remember" STYLE="color:white">
               Chrome Finish
               <input type="checkbox" name="remember" STYLE="color:white">
               </div>
               <table style="border-spacing:20px">
               <tr>
               <th class="first-col"></th>
               <th>Perfect</th>
               <th>Repair</th>
               <th>Replace</th>
               <th>Modify</th>
               <th>Custom Price</th>
               </tr>
               <tr>
               <td class="first-col">Car Wheel Care</td>
               <td><input type="radio" value="none" name="rate" /></td>
               <td><input type="radio" value="none" name="rate" /></td>
               <td><input type="radio" value="none" name="rate" /></td>
               <td><input type="radio" value="none" name="rate" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <tr>
               <td class="first-col">Car Battery Care</td>
               <td><input type="radio" value="none" name="satisfied" /></td>
               <td><input type="radio" value="none" name="satisfied" /></td>
               <td><input type="radio" value="none" name="satisfied" /></td>
               <td><input type="radio" value="none" name="satisfied" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <tr>
               <td class="first-col">Car Denting Care</td>
               <td><input type="radio" value="none" name="prices" /></td>
               <td><input type="radio" value="none" name="prices" /></td>
               <td><input type="radio" value="none" name="prices" /></td>
               <td><input type="radio" value="none" name="prices" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <tr>
               <td class="first-col">Car Painting Care</td>
               <td><input type="radio" value="none" name="timeliness" /></td>
               <td><input type="radio" value="none" name="timeliness" /></td>
               <td><input type="radio" value="none" name="timeliness" /></td>
               <td><input type="radio" value="none" name="timeliness" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <tr>
               <td class="first-col">Car AC Service</td>
               <td><input type="radio" value="none" name="name" /></td>
               <td><input type="radio" value="none" name="name" /></td>
               <td><input type="radio" value="none" name="name" /></td>
               <td><input type="radio" value="none" name="name" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <tr>
               <td class="first-col">Car Engine Service</td>
               <td><input type="radio" value="none" name="recommend" /></td>
               <td><input type="radio" value="none" name="recommend" /></td>
               <td><input type="radio" value="none" name="recommend" /></td>
               <td><input type="radio" value="none" name="recommend" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <tr>
               <td class="first-col">
               <input type="checkbox" name="remember" STYLE="color:white">
               Custom Job :-
               <input type="text" class="inspectioninput" size="30" id="paint"  name="paint" placeholder="Job Name"> 
               </td>
               <td><input type="radio" value="none" name="custom1" /></td>
               <td><input type="radio" value="none" name="custom1" /></td>
               <td><input type="radio" value="none" name="custom1" /></td>
               <td><input type="radio" value="none" name="custom1" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <td class="first-col">
               <input type="checkbox" name="remember" STYLE="color:white">
               Custom Job :-
               <input type="text" class="inspectioninput" size="30" id="paint"  name="paint" placeholder="Job Name"> 
               </td>
               <td><input type="radio" value="none" name="custom2" /></td>
               <td><input type="radio" value="none" name="custom2" /></td>
               <td><input type="radio" value="none" name="custom2" /></td>
               <td><input type="radio" value="none" name="custom2" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <td class="first-col">
               <input type="checkbox" name="remember" STYLE="color:white">
               Custom Job :-
               <input type="text" class="inspectioninput" size="30" id="paint"  name="paint" placeholder="Job Name"> 
               </td>
               <td><input type="radio" value="none" name="custom3" /></td>
               <td><input type="radio" value="none" name="custom3" /></td>
               <td><input type="radio" value="none" name="custom3" /></td>
               <td><input type="radio" value="none" name="custom3" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               <td class="first-col">
               <input type="checkbox" name="remember" STYLE="color:white">
               Custom Job :-
               <input type="text" class="inspectioninput" size="30" id="paint"  name="paint" placeholder="Job Name"> 
               </td>
               <td><input type="radio" value="none" name="custom4" /></td>
               <td><input type="radio" value="none" name="custom4" /></td>
               <td><input type="radio" value="none" name="custom4" /></td>
               <td><input type="radio" value="none" name="custom4" /></td>
               <td><input type="text" class="inspectioninput" size="7" id="paint"  name="paint" placeholder="Optional"></td>
               </tr>
               </table>
               <h4>Custom Comments</h4>
               <textarea rows="3" style="size:30 "></textarea>
               <br>
               <br>
               <!--
                  <h4>Email</h4>
                  <small>Only if you want to hear more from us.</small>
                  <input class="email" type="text" name="name" />
                  <div class="btn-block">
                  <button type="submit" href="/">Send Feedback</button>
                  </div> 
                   -->
               <input  class="button" type="submit" value="Save & Submit">
               </form>
               </div>
               </div>
            </div>
            </form>
         </div>
      </section>
      <!-- login section finish -->
      <!-- footer section -->
      <footer class="center">
         <p style="color:white" >Some Text here<br>
            <a href="mailto:hege@example.com" style="color:white">EMAIL US</a>
      </footer>
      <!-- footer section finish -->
      </div>
   </body>
</html>